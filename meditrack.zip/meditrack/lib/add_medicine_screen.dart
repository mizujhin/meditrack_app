import 'package:flutter/material.dart';
import 'medicine_manager.dart'; // 🔵 NEW CODE - Import the manager

class AddMedicineScreen extends StatefulWidget {
  const AddMedicineScreen({super.key});

  @override
  _AddMedicineScreenState createState() => _AddMedicineScreenState();
}

class _AddMedicineScreenState extends State<AddMedicineScreen> {
  final TextEditingController medicineController = TextEditingController();
  final TextEditingController dosageController = TextEditingController();
  final TextEditingController notesController = TextEditingController();
  final TextEditingController stockController = TextEditingController();

  String? _selectedUnit = "mg";
  String? _selectedForm = "Tablet";
  String? _selectedFrequency = "Daily";
  TimeOfDay? _selectedTime;
  DateTime? _startDate;

  final List<String> _medicineUnits = [
    'mg',
    'g',
    'ml',
    'mcg',
    'IU',
    'tablet(s)',
    'capsule(s)',
    'drop(s)',
    'puff(s)'
  ];

  final List<String> _medicineForms = [
    'Tablet',
    'Capsule',
    'Syrup',
    'Injection',
    'Drops',
    'Inhaler',
    'Cream',
    'Patch'
  ];

  final List<Map<String, dynamic>> _frequencies = [
    {'label': 'Once Daily', 'value': 'Daily'},
    {'label': 'Twice Daily', 'value': 'Twice Daily'},
    {'label': 'Three Times Daily', 'value': '3x Daily'},
    {'label': 'Every 12 Hours', 'value': 'Every 12hrs'},
    {'label': 'Weekly', 'value': 'Weekly'},
    {'label': 'As Needed', 'value': 'As Needed'},
  ];

  Future<void> _pickTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  Future<void> _pickStartDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 365)),
    );
    if (picked != null) {
      setState(() {
        _startDate = picked;
      });
    }
  }

  // 🔵 UPDATED FUNCTION - This saves medicine to the manager
  void _saveMedicine() {
    if (medicineController.text.isEmpty || dosageController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Please fill in medicine name and dosage"),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    // 🔵 NEW CODE - Check if time is selected
    if (_selectedTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("Please select a time for the reminder"),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    String medicine = medicineController.text;
    String dosage = dosageController.text;
    String unit = _selectedUnit ?? "mg";
    String form = _selectedForm ?? "Tablet";
    String freq = _selectedFrequency ?? "Daily";
    String time = _selectedTime!.format(context);

    // 🔵 NEW CODE - Create Medicine object and add to manager
    Medicine newMedicine = Medicine(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: medicine,
      dosage: dosage,
      unit: unit,
      form: form,
      frequency: freq,
      time: _selectedTime!,
      startDate: _startDate,
      stock: stockController.text.isNotEmpty ? stockController.text : null,
      notes: notesController.text.isNotEmpty ? notesController.text : null,
      createdAt: DateTime.now(),
    );

    // 🔵 NEW CODE - Add to medicine manager
    MedicineManager().addMedicine(newMedicine);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text("✓ Saved: $medicine ($form) - $dosage $unit, at $time, $freq"),
        backgroundColor: Colors.green,
        duration: Duration(seconds: 3),
      ),
    );

    medicineController.clear();
    dosageController.clear();
    notesController.clear();
    stockController.clear();
    setState(() {
      _selectedTime = null;
      _startDate = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Card(
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.medication_rounded, 
                    size: 28, 
                    color: Theme.of(context).colorScheme.primary),
                  SizedBox(width: 12),
                  Text(
                    "Add New Medicine",
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 20),
              TextField(
                controller: medicineController,
                decoration: InputDecoration(
                  labelText: "Medicine Name *",
                  hintText: "e.g., Aspirin",
                  prefixIcon: Icon(Icons.medication),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
                ),
              ),
              SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _selectedForm,
                decoration: InputDecoration(
                  labelText: "Medicine Form",
                  prefixIcon: Icon(Icons.category),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
                ),
                items: _medicineForms.map((String form) {
                  return DropdownMenuItem<String>(
                    value: form,
                    child: Text(form),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedForm = newValue;
                  });
                },
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: TextField(
                      controller: dosageController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: "Dosage *",
                        hintText: "e.g., 500",
                        prefixIcon: Icon(Icons.format_list_numbered),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
                      ),
                    ),
                  ),
                  SizedBox(width: 10),
                  Expanded(
                    flex: 2,
                    child: DropdownButtonFormField<String>(
                      value: _selectedUnit,
                      decoration: InputDecoration(
                        labelText: "Unit",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                        fillColor: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
                      ),
                      items: _medicineUnits.map((String unit) {
                        return DropdownMenuItem<String>(
                          value: unit,
                          child: Text(unit),
                        );
                      }).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          _selectedUnit = newValue;
                        });
                      },
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16),
              Text(
                "Frequency *",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: _frequencies.map((freq) {
                  bool isSelected = _selectedFrequency == freq['value'];
                  return ChoiceChip(
                    label: Text(freq['label']),
                    selected: isSelected,
                    selectedColor: Theme.of(context).colorScheme.primary,
                    labelStyle: TextStyle(
                      color: isSelected ? Colors.white : null,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                    ),
                    onSelected: (selected) {
                      setState(() {
                        _selectedFrequency = freq['value'];
                      });
                    },
                  );
                }).toList(),
              ),
              SizedBox(height: 16),
              InkWell(
                onTap: () => _pickTime(context),
                child: Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(12),
                    color: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.access_time, color: Theme.of(context).colorScheme.primary),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _selectedTime == null
                              ? "Select Time *"
                              : "Time: ${_selectedTime!.format(context)}",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: _selectedTime != null ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                      ),
                      Icon(Icons.keyboard_arrow_right),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16),
              InkWell(
                onTap: () => _pickStartDate(context),
                child: Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(12),
                    color: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.calendar_today, color: Theme.of(context).colorScheme.primary),
                      SizedBox(width: 12),
                      Expanded(
                        child: Text(
                          _startDate == null
                              ? "Start Date (Optional)"
                              : "Start: ${_startDate!.day}/${_startDate!.month}/${_startDate!.year}",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: _startDate != null ? FontWeight.w600 : FontWeight.normal,
                          ),
                        ),
                      ),
                      Icon(Icons.keyboard_arrow_right),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16),
              TextField(
                controller: stockController,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: "Stock Count (Optional)",
                  hintText: "e.g., 30",
                  helperText: "Number of pills/doses remaining",
                  prefixIcon: Icon(Icons.inventory_2),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
                ),
              ),
              SizedBox(height: 16),
              TextField(
                controller: notesController,
                maxLines: 3,
                decoration: InputDecoration(
                  labelText: "Notes / Instructions (Optional)",
                  hintText: "e.g., Take with food, avoid dairy",
                  prefixIcon: Icon(Icons.note),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  filled: true,
                  fillColor: Theme.of(context).colorScheme.secondary.withOpacity(0.1),
                ),
              ),
              SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  onPressed: _saveMedicine,
                  icon: Icon(Icons.save, size: 24),
                  label: Text(
                    "Save Medicine",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).colorScheme.primary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 4,
                  ),
                ),
              ),
              SizedBox(height: 12),
              Center(
                child: Text(
                  "* Required fields",
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}