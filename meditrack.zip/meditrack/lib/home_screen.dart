import 'package:flutter/material.dart';
import 'welcome_slider.dart';
import 'health_tracker_screen.dart';
import 'add_medicine_screen.dart';
import 'appointment_screen.dart';
import 'reminders_screen.dart';
import 'profile_screen.dart';  // Import the new ProfileScreen

class HomeScreen extends StatefulWidget {
  final VoidCallback toggleTheme;

  const HomeScreen({super.key, required this.toggleTheme});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  final List<Widget> _pages = [
    WelcomeSlider(),  // Index 0: Home
    HealthTrackerScreen(),  // Index 1: Vitals
    AddMedicineScreen(),  // Index 2: Medicine
    AppointmentScreen(),  // Index 3: Appointments
    RemindersScreen(),  // Index 4: Reminders
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: _buildSidebar(context),
      appBar: AppBar(
        title: Text("MediTrack"),
        leading: Builder(
          builder: (context) => IconButton(
            icon: Icon(Icons.menu),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(Icons.brightness_6),
            onPressed: widget.toggleTheme,
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: _pages[_selectedIndex],
      ),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.favorite), label: "Vitals"),
          BottomNavigationBarItem(icon: Icon(Icons.medication), label: "Medicine"),
          BottomNavigationBarItem(icon: Icon(Icons.calendar_month), label: "Appointments"),
          BottomNavigationBarItem(icon: Icon(Icons.notifications), label: "Reminders"),
        ],
      ),
    );
  }

  Widget _buildSidebar(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: BoxDecoration(color: Theme.of(context).colorScheme.primary),
            accountName: Text("John Doe"),
            accountEmail: Text("johndoe@example.com"),
            currentAccountPicture: CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.person, color: Colors.green, size: 40),
            ),
          ),
          ListTile(
            leading: Icon(Icons.person),
            title: Text("Profile"),
            onTap: () {
              Navigator.pop(context);  // Close drawer
              // Navigate to ProfileScreen
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileScreen()),
              );
            },
          ),
          ListTile(
            leading: Icon(Icons.notifications),
            title: Text("Reminders"),
            onTap: () {
              Navigator.pop(context);
              setState(() {
                _selectedIndex = 4;
              });
            },
          ),
          ListTile(
            leading: Icon(Icons.info_outline),
            title: Text("About App"),
            onTap: () {
              Navigator.pop(context);
              showAboutDialog(
                context: context,
                applicationName: "MediTrack",
                applicationVersion: "1.0.0",
                children: [
                  Text("MediTrack helps you monitor your health, track medicine intake, and manage appointments."),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}