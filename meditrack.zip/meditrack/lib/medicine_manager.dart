import 'package:flutter/material.dart';

// Simple Medicine Model
class Medicine {
  final String id;
  final String name;
  final String dosage;
  final String unit;
  final String form;
  final String frequency;
  final TimeOfDay time;
  final DateTime? startDate;
  final String? stock;
  final String? notes;
  final DateTime createdAt;

  Medicine({
    required this.id,
    required this.name,
    required this.dosage,
    required this.unit,
    required this.form,
    required this.frequency,
    required this.time,
    this.startDate,
    this.stock,
    this.notes,
    required this.createdAt,
  });
}

// Medicine Manager - Singleton pattern for global state
class MedicineManager extends ChangeNotifier {
  static final MedicineManager _instance = MedicineManager._internal();
  factory MedicineManager() => _instance;
  MedicineManager._internal();

  final List<Medicine> _medicines = [];

  List<Medicine> get medicines => List.unmodifiable(_medicines);

  void addMedicine(Medicine medicine) {
    _medicines.add(medicine);
    notifyListeners();
  }

  void removeMedicine(String id) {
    _medicines.removeWhere((med) => med.id == id);
    notifyListeners();
  }

  // Get reminders for display
  List<Map<String, dynamic>> getReminders() {
    return _medicines.map((medicine) {
      return {
        'id': medicine.id,
        'type': 'medicine',
        'status': 'now',
        'title': '${medicine.name} ${medicine.dosage}${medicine.unit}',
        'subtitle': '${medicine.frequency}',
        'actions': ['Take Now', 'Snooze'],
        'statusColor': Colors.green,
        'statusIcon': Icons.circle,
        'medicine': medicine,
      };
    }).toList();
  }
}