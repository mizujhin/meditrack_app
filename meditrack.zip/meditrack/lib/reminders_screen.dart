import 'package:flutter/material.dart';
import 'medicine_manager.dart'; // 🔵 

class RemindersScreen extends StatefulWidget {
  const RemindersScreen({super.key});

  @override
  _RemindersScreenState createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen> {
  String _selectedFilter = "Today";
  final MedicineManager _medicineManager = MedicineManager(); 

  // 🔵 NEW CODE - Listen to changes
  @override
  void initState() {
    super.initState();
    _medicineManager.addListener(_onMedicinesChanged);
  }

  @override
  void dispose() {
    _medicineManager.removeListener(_onMedicinesChanged);
    super.dispose();
  }

  void _onMedicinesChanged() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    // 🔵 NEW CODE - Get reminders from manager instead of hardcoded list
    List<Map<String, dynamic>> reminders = _medicineManager.getReminders();
    
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: SafeArea(
        child: Column(
          children: [
            // Header
            Container(
              padding: EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                border: Border(
                  bottom: BorderSide(
                    color: Theme.of(context).dividerColor,
                    width: 1,
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Reminders (Active: ${reminders.length})", // 🔵 UPDATED - Dynamic count
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).colorScheme.onSurface,
                    ),
                  ),
                  SizedBox(height: 12),
                  // Filter Chips
                  Row(
                    children: [
                      _buildFilterChip("[Today]", "Today"),
                      SizedBox(width: 8),
                      _buildFilterChip("[Upcoming]", "Upcoming"),
                      SizedBox(width: 8),
                      _buildFilterChip("[Missed]", "Missed"),
                    ],
                  ),
                ],
              ),
            ),

            // Reminders List
            Expanded(
              child: reminders.isEmpty // 🔵 NEW CODE - Check if empty
                  ? _buildEmptyState() // 🔵 NEW CODE - Show empty state
                  : ListView.builder(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      itemCount: reminders.length + 1,
                      itemBuilder: (context, index) {
                        if (index == reminders.length) {
                          return _buildAdherenceCard(reminders.length);
                        }
                        return _buildReminderCard(reminders[index]);
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  // 🔵 NEW CODE - Empty state widget
  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.notifications_none,
            size: 80,
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.3),
          ),
          SizedBox(height: 16),
          Text(
            "No reminders yet",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
            ),
          ),
          SizedBox(height: 8),
          Text(
            "Add medicines to see reminders here",
            style: TextStyle(
              fontSize: 14,
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.5),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChip(String label, String value) {
    bool isSelected = _selectedFilter == value;
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedFilter = value;
        });
      },
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected 
              ? Theme.of(context).colorScheme.primary.withOpacity(0.2)
              : Colors.transparent,
          border: Border.all(
            color: isSelected 
                ? Theme.of(context).colorScheme.primary
                : Theme.of(context).dividerColor,
          ),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 14,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: isSelected 
                ? Theme.of(context).colorScheme.primary
                : Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
          ),
        ),
      ),
    );
  }

  Widget _buildReminderCard(Map<String, dynamic> reminder) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border.all(
          color: Theme.of(context).dividerColor,
          width: 1,
        ),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Status and Title Row
            Row(
              children: [
                Icon(
                  reminder['statusIcon'],
                  color: reminder['statusColor'],
                  size: 16,
                ),
                SizedBox(width: 8),
                Expanded(
                  child: RichText(
                    text: TextSpan(
                      style: TextStyle(
                        fontSize: 14,
                        color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                      ),
                      children: [
                        TextSpan(
                          text: _getStatusText(reminder['status']),
                          style: TextStyle(fontWeight: FontWeight.w500),
                        ),
                        TextSpan(text: " • "),
                        TextSpan(
                          text: _getTypeText(reminder['type']),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 8),
            // Title
            Text(
              reminder['title'],
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.onSurface,
              ),
            ),
            if (reminder['subtitle'] != null) ...[
              SizedBox(height: 4),
              Text(
                reminder['subtitle'],
                style: TextStyle(
                  fontSize: 14,
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
                ),
              ),
            ],
            SizedBox(height: 12),
            // Action Buttons
            Row(
              children: reminder['actions'].map<Widget>((action) {
                int actionIndex = reminder['actions'].indexOf(action);
                return Padding(
                  padding: EdgeInsets.only(right: actionIndex < reminder['actions'].length - 1 ? 8 : 0),
                  child: _buildActionButton(action, reminder['id']), // 🔵 UPDATED - Pass ID
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }

  // 🔵 UPDATED - Added reminderId parameter
  Widget _buildActionButton(String label, String? reminderId) {
    return OutlinedButton(
      onPressed: () {
        // 🔵 NEW CODE - Remove medicine when "Take Now" is pressed
        if (label == "Take Now" && reminderId != null) {
          _medicineManager.removeMedicine(reminderId);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text("Medicine marked as taken"),
              duration: Duration(seconds: 2),
              backgroundColor: Colors.green,
            ),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text("$label pressed"),
              duration: Duration(seconds: 1),
            ),
          );
        }
      },
      style: OutlinedButton.styleFrom(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        side: BorderSide(
          color: Theme.of(context).dividerColor,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(6),
        ),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 13,
          color: Theme.of(context).colorScheme.onSurface,
        ),
      ),
    );
  }

  Widget _buildAdherenceCard(int totalReminders) {
    int adherencePercentage = totalReminders > 0 ? 92 : 100;
    
    return Container(
      margin: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        border: Border.all(
          color: Theme.of(context).dividerColor,
          width: 1,
        ),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Padding(
        padding: EdgeInsets.all(12),
        child: Row(
          children: [
            Icon(
              Icons.star,
              color: Colors.amber,
              size: 20,
            ),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                "Adherence This Week: $adherencePercentage%",
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.onSurface,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'now':
        return 'Now';
      case 'upcoming':
        return 'In 2 hours';
      case 'overdue':
        return 'Overdue';
      case 'warning':
        return 'Low Stock Alert';
      default:
        return status;
    }
  }

  String _getTypeText(String type) {
    switch (type) {
      case 'medicine':
        return 'Medicine';
      case 'appointment':
        return 'Appointment';
      case 'alert':
        return '';
      default:
        return type;
    }
  }
}