import 'package:flutter/material.dart';

class HealthTrackerScreen extends StatefulWidget {
  const HealthTrackerScreen({super.key});

  @override
  _HealthTrackerScreenState createState() => _HealthTrackerScreenState();
}

class _HealthTrackerScreenState extends State<HealthTrackerScreen> {
  final TextEditingController bpSystolicController = TextEditingController();
  final TextEditingController bpDiastolicController = TextEditingController();
  final TextEditingController sugarController = TextEditingController();
  final TextEditingController weightController = TextEditingController();
  final TextEditingController heightController = TextEditingController();
  final TextEditingController heartRateController = TextEditingController();
  final TextEditingController temperatureController = TextEditingController();
  final TextEditingController oxygenController = TextEditingController();
  final TextEditingController sleepController = TextEditingController();
  final TextEditingController waterController = TextEditingController();

  String _calculateBMI() {
    if (weightController.text.isNotEmpty && heightController.text.isNotEmpty) {
      double weight = double.tryParse(weightController.text) ?? 0;
      double height = double.tryParse(heightController.text) ?? 0;
      if (weight > 0 && height > 0) {
        double bmi = weight / ((height / 100) * (height / 100));
        return bmi.toStringAsFixed(1);
      }
    }
    return "N/A";
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Track Your Vitals",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 20),
                  Text(
                    "Blood Pressure",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: bpSystolicController,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: "Systolic",
                            hintText: "120",
                            prefixIcon: Icon(Icons.favorite),
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                      SizedBox(width: 10),
                      Text("/", style: TextStyle(fontSize: 24)),
                      SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: bpDiastolicController,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            labelText: "Diastolic",
                            hintText: "80",
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 16),
                  TextField(
                    controller: sugarController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: "Blood Sugar (mg/dL)",
                      hintText: "100",
                      prefixIcon: Icon(Icons.bloodtype),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 16),
                  TextField(
                    controller: heartRateController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: "Heart Rate (BPM)",
                      hintText: "70",
                      prefixIcon: Icon(Icons.favorite_border),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 16),
                  TextField(
                    controller: oxygenController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: "Oxygen Saturation (SpO2%)",
                      hintText: "98",
                      prefixIcon: Icon(Icons.air),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 16),
                  TextField(
                    controller: temperatureController,
                    keyboardType: TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                      labelText: "Body Temperature (°C)",
                      hintText: "36.5",
                      prefixIcon: Icon(Icons.thermostat),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: weightController,
                          keyboardType: TextInputType.numberWithOptions(decimal: true),
                          decoration: InputDecoration(
                            labelText: "Weight (kg)",
                            hintText: "70",
                            prefixIcon: Icon(Icons.monitor_weight),
                            border: OutlineInputBorder(),
                          ),
                          onChanged: (value) => setState(() {}),
                        ),
                      ),
                      SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          controller: heightController,
                          keyboardType: TextInputType.numberWithOptions(decimal: true),
                          decoration: InputDecoration(
                            labelText: "Height (cm)",
                            hintText: "170",
                            prefixIcon: Icon(Icons.height),
                            border: OutlineInputBorder(),
                          ),
                          onChanged: (value) => setState(() {}),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 12),
                  Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.secondary.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          "BMI:",
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                        ),
                        Text(
                          _calculateBMI(),
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16),
                  TextField(
                    controller: sleepController,
                    keyboardType: TextInputType.numberWithOptions(decimal: true),
                    decoration: InputDecoration(
                      labelText: "Sleep Hours",
                      hintText: "8",
                      prefixIcon: Icon(Icons.bedtime),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 16),
                  TextField(
                    controller: waterController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: "Water Intake (glasses)",
                      hintText: "8",
                      prefixIcon: Icon(Icons.local_drink),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        Map<String, dynamic> healthData = {
                          'bpSystolic': bpSystolicController.text,
                          'bpDiastolic': bpDiastolicController.text,
                          'sugar': sugarController.text,
                          'weight': weightController.text,
                          'height': heightController.text,
                          'heartRate': heartRateController.text,
                          'temperature': temperatureController.text,
                          'oxygen': oxygenController.text,
                          'sleep': sleepController.text,
                          'water': waterController.text,
                          'bmi': _calculateBMI(),
                        };
                        
                        Navigator.pushNamed(
                          context,
                          '/history',
                          arguments: healthData,
                        );
                        
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text("Health Stats Saved and Going to History!"),
                            duration: Duration(seconds: 2),
                          ),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 14),
                        backgroundColor: Theme.of(context).colorScheme.primary,
                        foregroundColor: Colors.white,
                      ),
                      child: Text("Save Stats", style: TextStyle(fontSize: 16)),
                    ),
                  ),
                  SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        // NEW: Navigate to HistoryScreen when "View History" is pressed
                        Navigator.pushNamed(context, '/history');
                        // If you want to pass data or do something else, let me know!
                      },
                      style: ElevatedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 14),
                        backgroundColor: Color(0xFFE57373),
                        foregroundColor: Colors.white,
                      ),
                      child: Text("View History", style: TextStyle(fontSize: 16)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}