import 'package:flutter/material.dart';

class AppointmentScreen extends StatefulWidget {
  const AppointmentScreen({super.key});

  @override
  _AppointmentScreenState createState() => _AppointmentScreenState();
}

class _AppointmentScreenState extends State<AppointmentScreen> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController doctorController = TextEditingController();
  final TextEditingController specialtyController = TextEditingController();
  final TextEditingController locationController = TextEditingController();
  final TextEditingController notesController = TextEditingController();

  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  String? _selectedType = "Check-up";
  bool _showCalendar = false; // Toggle between list and calendar view
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedCalendarDay;

  final List<String> _appointmentTypes = [
    "Check-up",
    "Follow-up",
    "Consultation",
    "Lab Test",
    "Vaccination",
    "Emergency",
    "Dental",
    "Eye Check",
  ];

  final List<Map<String, dynamic>> _appointments = [
    {
      'title': 'General Check-up',
      'doctor': 'Dr. Smith',
      'specialty': 'General Physician',
      'date': 'Sept 25, 2024',
      'time': '3:00 PM',
      'location': 'City Medical Center',
      'type': 'Check-up',
      'status': 'Upcoming',
      'dateTime': DateTime(2024, 9, 25),
    },
  ];

  Future<void> _pickDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(Duration(days: 365)),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _pickTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
    if (picked != null) {
      setState(() {
        _selectedTime = picked;
      });
    }
  }

  void _showAddAppointmentDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: StatefulBuilder(
            builder: (context, setDialogState) {
              return SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.all(20.0),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.calendar_month, 
                            size: 28, 
                            color: Theme.of(context).colorScheme.primary),
                          SizedBox(width: 12),
                          Text(
                            "Add Appointment",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      TextField(
                        controller: titleController,
                        decoration: InputDecoration(
                          labelText: "Appointment Title *",
                          hintText: "e.g., Annual Check-up",
                          prefixIcon: Icon(Icons.title),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                      SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: _selectedType,
                        decoration: InputDecoration(
                          labelText: "Appointment Type",
                          prefixIcon: Icon(Icons.category),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        items: _appointmentTypes.map((String type) {
                          return DropdownMenuItem<String>(
                            value: type,
                            child: Text(type),
                          );
                        }).toList(),
                        onChanged: (String? newValue) {
                          setDialogState(() {
                            _selectedType = newValue;
                          });
                        },
                      ),
                      SizedBox(height: 16),
                      TextField(
                        controller: doctorController,
                        decoration: InputDecoration(
                          labelText: "Doctor Name *",
                          hintText: "e.g., Dr. John Smith",
                          prefixIcon: Icon(Icons.person),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                      SizedBox(height: 16),
                      TextField(
                        controller: specialtyController,
                        decoration: InputDecoration(
                          labelText: "Specialty",
                          hintText: "e.g., Cardiologist",
                          prefixIcon: Icon(Icons.medical_services),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                      SizedBox(height: 16),
                      InkWell(
                        onTap: () async {
                          await _pickDate(context);
                          setDialogState(() {});
                        },
                        child: Container(
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.calendar_today, 
                                color: Theme.of(context).colorScheme.primary),
                              SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  _selectedDate == null
                                      ? "Select Date *"
                                      : "${_selectedDate!.day}/${_selectedDate!.month}/${_selectedDate!.year}",
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: _selectedDate != null 
                                      ? FontWeight.w600 
                                      : FontWeight.normal,
                                  ),
                                ),
                              ),
                              Icon(Icons.keyboard_arrow_right),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 16),
                      InkWell(
                        onTap: () async {
                          await _pickTime(context);
                          setDialogState(() {});
                        },
                        child: Container(
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.grey),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.access_time, 
                                color: Theme.of(context).colorScheme.primary),
                              SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  _selectedTime == null
                                      ? "Select Time *"
                                      : _selectedTime!.format(context),
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: _selectedTime != null 
                                      ? FontWeight.w600 
                                      : FontWeight.normal,
                                  ),
                                ),
                              ),
                              Icon(Icons.keyboard_arrow_right),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 16),
                      TextField(
                        controller: locationController,
                        decoration: InputDecoration(
                          labelText: "Location/Hospital",
                          hintText: "e.g., City Medical Center",
                          prefixIcon: Icon(Icons.location_on),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                      SizedBox(height: 16),
                      TextField(
                        controller: notesController,
                        maxLines: 3,
                        decoration: InputDecoration(
                          labelText: "Notes (Optional)",
                          hintText: "Questions to ask, things to bring...",
                          prefixIcon: Icon(Icons.note),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                      SizedBox(height: 24),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () {
                                Navigator.pop(context);
                                titleController.clear();
                                doctorController.clear();
                                specialtyController.clear();
                                locationController.clear();
                                notesController.clear();
                                setState(() {
                                  _selectedDate = null;
                                  _selectedTime = null;
                                });
                              },
                              style: OutlinedButton.styleFrom(
                                padding: EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: Text("Cancel"),
                            ),
                          ),
                          SizedBox(width: 12),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () {
                                if (titleController.text.isEmpty ||
                                    doctorController.text.isEmpty ||
                                    _selectedDate == null ||
                                    _selectedTime == null) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text("Please fill required fields"),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                  return;
                                }
                                Navigator.pop(context);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    content: Text("✓ Appointment Added Successfully!"),
                                    backgroundColor: Colors.green,
                                  ),
                                );
                                titleController.clear();
                                doctorController.clear();
                                specialtyController.clear();
                                locationController.clear();
                                notesController.clear();
                                setState(() {
                                  _selectedDate = null;
                                  _selectedTime = null;
                                });
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Theme.of(context).colorScheme.primary,
                                foregroundColor: Colors.white,
                                padding: EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                              ),
                              child: Text("Save"),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  void _showDoctorDetails(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          title: Row(
            children: [
              CircleAvatar(
                radius: 25,
                backgroundColor: Theme.of(context).colorScheme.primary,
                child: Icon(Icons.person, color: Colors.white, size: 30),
              ),
              SizedBox(width: 12),
              Text("Doctor Details"),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildInfoRow(Icons.person, "Name", "Dr. Smith"),
              _buildInfoRow(Icons.medical_services, "Specialty", "Cardiologist"),
              _buildInfoRow(Icons.phone, "Contact", "123-456-7890"),
              _buildInfoRow(Icons.email, "Email", "dr.smith@hospital.com"),
              _buildInfoRow(Icons.location_on, "Clinic", "City Medical Center"),
            ],
          ),
          actions: [
            TextButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: Icon(Icons.close),
              label: Text("Close"),
            ),
            ElevatedButton.icon(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Calling Dr. Smith...")),
                );
              },
              icon: Icon(Icons.phone),
              label: Text("Call"),
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.grey),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Upcoming':
        return Colors.blue;
      case 'Completed':
        return Colors.green;
      case 'Cancelled':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  IconData _getTypeIcon(String type) {
    switch (type) {
      case 'Check-up':
        return Icons.health_and_safety;
      case 'Follow-up':
        return Icons.update;
      case 'Lab Test':
        return Icons.biotech;
      case 'Vaccination':
        return Icons.vaccines;
      case 'Emergency':
        return Icons.emergency;
      case 'Dental':
        return Icons.face_retouching_natural;
      default:
        return Icons.medical_services;
    }
  }

  List<Map<String, dynamic>> _getAppointmentsForDay(DateTime day) {
    return _appointments.where((appointment) {
      DateTime appointmentDate = appointment['dateTime'];
      return appointmentDate.year == day.year &&
             appointmentDate.month == day.month &&
             appointmentDate.day == day.day;
    }).toList();
  }

  bool _hasAppointmentOnDay(DateTime day) {
    return _appointments.any((appointment) {
      DateTime appointmentDate = appointment['dateTime'];
      return appointmentDate.year == day.year &&
             appointmentDate.month == day.month &&
             appointmentDate.day == day.day;
    });
  }

  Widget _buildCalendarView() {
    return Column(
      children: [
        // Month Navigation
        Container(
          padding: EdgeInsets.symmetric(vertical: 12, horizontal: 16),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                icon: Icon(Icons.chevron_left),
                onPressed: () {
                  setState(() {
                    _focusedDay = DateTime(_focusedDay.year, _focusedDay.month - 1);
                  });
                },
              ),
              Text(
                "${_getMonthName(_focusedDay.month)} ${_focusedDay.year}",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              IconButton(
                icon: Icon(Icons.chevron_right),
                onPressed: () {
                  setState(() {
                    _focusedDay = DateTime(_focusedDay.year, _focusedDay.month + 1);
                  });
                },
              ),
            ],
          ),
        ),
        SizedBox(height: 16),
        // Weekday Headers
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
              .map((day) => Expanded(
                    child: Center(
                      child: Text(
                        day,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                    ),
                  ))
              .toList(),
        ),
        SizedBox(height: 8),
        // Calendar Grid
        ..._buildCalendarDays(),
        SizedBox(height: 20),
        // Selected Day Appointments
        if (_selectedCalendarDay != null) ...[
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "Appointments on ${_selectedCalendarDay!.day}/${_selectedCalendarDay!.month}/${_selectedCalendarDay!.year}",
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          SizedBox(height: 12),
          ..._getAppointmentsForDay(_selectedCalendarDay!).map((appointment) {
            return _buildAppointmentCard(appointment);
          }).toList(),
          if (_getAppointmentsForDay(_selectedCalendarDay!).isEmpty)
            Center(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Text(
                  "No appointments on this day",
                  style: TextStyle(color: Colors.grey),
                ),
              ),
            ),
        ],
      ],
    );
  }

  List<Widget> _buildCalendarDays() {
    List<Widget> weeks = [];
    DateTime firstDayOfMonth = DateTime(_focusedDay.year, _focusedDay.month, 1);
    DateTime lastDayOfMonth = DateTime(_focusedDay.year, _focusedDay.month + 1, 0);
    
    int startingWeekday = firstDayOfMonth.weekday % 7;
    int daysInMonth = lastDayOfMonth.day;
    
    List<Widget> dayWidgets = [];
    
    // Add empty cells for days before the month starts
    for (int i = 0; i < startingWeekday; i++) {
      dayWidgets.add(Expanded(child: SizedBox()));
    }
    
    // Add cells for each day of the month
    for (int day = 1; day <= daysInMonth; day++) {
      DateTime currentDay = DateTime(_focusedDay.year, _focusedDay.month, day);
      bool isToday = currentDay.year == DateTime.now().year &&
                     currentDay.month == DateTime.now().month &&
                     currentDay.day == DateTime.now().day;
      bool isSelected = _selectedCalendarDay != null &&
                       currentDay.year == _selectedCalendarDay!.year &&
                       currentDay.month == _selectedCalendarDay!.month &&
                       currentDay.day == _selectedCalendarDay!.day;
      bool hasAppointment = _hasAppointmentOnDay(currentDay);
      
      dayWidgets.add(
        Expanded(
          child: GestureDetector(
            onTap: () {
              setState(() {
                _selectedCalendarDay = currentDay;
              });
            },
            child: Container(
              margin: EdgeInsets.all(4),
              decoration: BoxDecoration(
                color: isSelected
                    ? Theme.of(context).colorScheme.primary
                    : isToday
                        ? Theme.of(context).colorScheme.primary.withOpacity(0.3)
                        : Colors.transparent,
                borderRadius: BorderRadius.circular(8),
                border: hasAppointment
                    ? Border.all(
                        color: Theme.of(context).colorScheme.primary,
                        width: 2,
                      )
                    : null,
              ),
              child: Center(
                child: Text(
                  '$day',
                  style: TextStyle(
                    color: isSelected ? Colors.white : null,
                    fontWeight: hasAppointment ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
              ),
            ),
          ),
        ),
      );
      
      // Create a new row after every 7 days
      if ((startingWeekday + day) % 7 == 0 || day == daysInMonth) {
        // Fill remaining cells in the week if it's the last day
        if (day == daysInMonth) {
          int remainingCells = 7 - ((startingWeekday + day) % 7);
          if (remainingCells < 7) {
            for (int i = 0; i < remainingCells; i++) {
              dayWidgets.add(Expanded(child: SizedBox()));
            }
          }
        }
        weeks.add(
          Padding(
            padding: EdgeInsets.symmetric(vertical: 4),
            child: Row(
              children: List.from(dayWidgets),
            ),
          ),
        );
        dayWidgets.clear();
      }
    }
    
    return weeks;
  }

  String _getMonthName(int month) {
    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return monthNames[month - 1];
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          // View Toggle Buttons
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    setState(() {
                      _showCalendar = true;
                    });
                  },
                  icon: Icon(Icons.calendar_view_month),
                  label: Text("Calendar"),
                  style: OutlinedButton.styleFrom(
                    backgroundColor: _showCalendar 
                        ? Theme.of(context).colorScheme.primary.withOpacity(0.1)
                        : null,
                    padding: EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 12),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    setState(() {
                      _showCalendar = false;
                    });
                  },
                  icon: Icon(Icons.list),
                  label: Text("List"),
                  style: OutlinedButton.styleFrom(
                    backgroundColor: !_showCalendar 
                        ? Theme.of(context).colorScheme.primary.withOpacity(0.1)
                        : null,
                    padding: EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16),
          
          // Show either calendar or list view
          if (_showCalendar)
            _buildCalendarView()
          else
            ..._appointments.map((appointment) {
              return _buildAppointmentCard(appointment);
            }).toList(),
          
          SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                _showAddAppointmentDialog(context);
              },
              icon: Icon(Icons.add, size: 24),
              label: Text("Add Appointment", style: TextStyle(fontSize: 16)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
                foregroundColor: Colors.white,
                padding: EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                elevation: 2,
              ),
            ),
          ),
          SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: () {
                _showDoctorDetails(context);
              },
              icon: Icon(Icons.person),
              label: Text("View Doctors"),
              style: OutlinedButton.styleFrom(
                padding: EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAppointmentCard(Map<String, dynamic> appointment) {
    return Card(
      margin: EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {},
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      _getTypeIcon(appointment['type']),
                      color: Theme.of(context).colorScheme.primary,
                      size: 28,
                    ),
                  ),
                  SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          appointment['title'],
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        SizedBox(height: 4),
                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: _getStatusColor(appointment['status']).withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            appointment['status'],
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              color: _getStatusColor(appointment['status']),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.more_vert),
                    onPressed: () {},
                  ),
                ],
              ),
              SizedBox(height: 16),
              Divider(),
              SizedBox(height: 12),
              _buildDetailRow(Icons.person, appointment['doctor'], appointment['specialty']),
              SizedBox(height: 8),
              _buildDetailRow(Icons.calendar_today, appointment['date'], appointment['time']),
              SizedBox(height: 8),
              _buildDetailRow(Icons.location_on, appointment['location'], null),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(IconData icon, String text, String? subtext) {
    return Row(
      children: [
        Icon(icon, size: 18, color: Colors.grey),
        SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                text,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                ),
              ),
              if (subtext != null)
                Text(
                  subtext,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),
            ],
          ),
        ),
      ],
    );
  }
}