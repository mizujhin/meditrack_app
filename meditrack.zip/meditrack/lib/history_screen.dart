import 'package:flutter/material.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  _HistoryScreenState createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  Map<String, dynamic>? receivedHealthData;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;
      if (args != null) {
        setState(() {
          receivedHealthData = args;  // Store the passed data
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Health History"),
        backgroundColor: Theme.of(context).colorScheme.primary,
      ),
      body: SafeArea(
        child: Center(
          child: receivedHealthData != null
              ? Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Saved Health Stats:",
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      SizedBox(height: 10),
                      Text("BP: ${receivedHealthData?['bpSystolic']}/${receivedHealthData?['bpDiastolic']}"),
                      Text("Blood Sugar: ${receivedHealthData?['sugar']} mg/dL"),
                      Text("Weight: ${receivedHealthData?['weight']} kg"),
                      Text("Height: ${receivedHealthData?['height']} cm"),
                      Text("Heart Rate: ${receivedHealthData?['heartRate']} BPM"),
                      Text("Temperature: ${receivedHealthData?['temperature']} °C"),
                      Text("Oxygen: ${receivedHealthData?['oxygen']}%"),
                      Text("Sleep: ${receivedHealthData?['sleep']} hours"),
                      Text("Water: ${receivedHealthData?['water']} glasses"),
                      Text("BMI: ${receivedHealthData?['bmi']}"),
                      // You can add more UI elements here, like a list for multiple history items
                    ],
                  ),
                )
              : Text("No data received yet."),
        ),
      ),
    );
  }
}