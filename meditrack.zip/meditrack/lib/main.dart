import 'package:flutter/material.dart';
import 'login_screen.dart';  // Existing import
import 'health_tracker_screen.dart';  // for HealthTrackerScreen
import 'reminders_screen.dart';  // for RemindersScreen
import 'history_screen.dart';  // for HistoryScreen
import 'add_medicine_screen.dart';  // import for AddMedicineScreen

void main() {
  runApp(MediTrackApp());
}

class MediTrackApp extends StatefulWidget {
  const MediTrackApp({super.key});

  @override
  _MediTrackAppState createState() => _MediTrackAppState();
}

class _MediTrackAppState extends State<MediTrackApp> {
  ThemeMode _themeMode = ThemeMode.light;

  void _toggleTheme() {
    setState(() {
      _themeMode = _themeMode == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "MediTrack",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: const ColorScheme.light(
          primary: Color(0xFF4CAF50),
          secondary: Color(0xFFE8F5E9),
          surface: Colors.white,
        ),
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: const ColorScheme.dark(
          primary: Colors.greenAccent,
          surface: Color(0xFF1E1E1E),
        ),
      ),
      themeMode: _themeMode,
      home: LoginScreen(toggleTheme: _toggleTheme), // for Home screen remains Login
      routes: {
        '/healthtracker': (context) => const HealthTrackerScreen(),  // Route for Health Tracker
        '/reminders': (context) => const RemindersScreen(),          // Route for Reminders
        '/history': (context) => const HistoryScreen(),              // Route for History
        '/add_medicine': (context) => const AddMedicineScreen(),     // Route for Add Medicine
      },
    );
  }
}
